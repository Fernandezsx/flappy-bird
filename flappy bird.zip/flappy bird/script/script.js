  // Variáveis do jogo
    let move_speed = 3;
    let gravity = 0.5;
    let speed_increase_interval = 10;
    let speed_increase_amount = 0.2;
    
    // Elementos do jogo
    let bird = document.querySelector('.bird');
    let bird_props = bird.getBoundingClientRect();
    let background = document.querySelector('.background').getBoundingClientRect();
    let score_val = document.querySelector('.score_val');
    let message = document.querySelector('.message');
    let score_title = document.querySelector('.score_title');
    let difficulty_menu = document.querySelector('.difficulty');
    let high_scores_menu = document.querySelector('.high-scores');
    let high_scores_list = document.getElementById('high-scores-list');
    
    // Estado do jogo
    let game_state = 'Start';
    let base_speed = move_speed;
    let base_gravity = gravity;
    
    // Mostrar menu de dificuldade
    function showDifficultyMenu() {
      difficulty_menu.style.display = 'block';
      game_state = 'Menu';
    }
    
    // Mostrar pontuações mais altas
    function showHighScores() {
      high_scores_menu.style.display = 'block';
      updateHighScoresList();
    }
    
    // Fechar pontuações mais altas
    document.querySelector('.close-btn').addEventListener('click', () => {
      high_scores_menu.style.display = 'none';
    });
    
    // Atualizar lista de pontuações mais altas
    function updateHighScoresList() {
      let scores = JSON.parse(localStorage.getItem('flappyBirdHighScores')) || [];
      high_scores_list.innerHTML = '';
      
      scores.slice(0, 5).forEach((score, index) => {
        let li = document.createElement('li');
        li.textContent = `${index + 1}. ${score.points} pontos (${score.difficulty})`;
        high_scores_list.appendChild(li);
      });
    }
    
    // Salvar pontuação
    function saveScore(points, difficulty) {
      let scores = JSON.parse(localStorage.getItem('flappyBirdHighScores')) || [];
      scores.push({
        points: points,
        difficulty: difficulty,
        date: new Date().toLocaleDateString()
      });
      
      // Ordenar por pontuação (maior primeiro)
      scores.sort((a, b) => b.points - a.points);
      
      // Manter apenas as 5 melhores
      if (scores.length > 5) {
        scores = scores.slice(0, 5);
      }
      
      localStorage.setItem('flappyBirdHighScores', JSON.stringify(scores));
    }
    
    // Configurar dificuldade
    function setDifficulty(level) {
      difficulty_menu.style.display = 'none';
      
      switch(level) {
        case 'easy':
          move_speed = 2;
          gravity = 0.4;
          message.innerHTML = 'Modo Fácil - Pressione Enter';
          break;
        case 'normal':
          move_speed = 3;
          gravity = 0.5;
          message.innerHTML = 'Modo Normal - Pressione Enter';
          break;
        case 'hard':
          move_speed = 4;
          gravity = 0.6;
          message.innerHTML = 'Modo Difícil - Pressione Enter';
          break;
      }
      
      base_speed = move_speed;
      base_gravity = gravity;
      game_state = 'Start';
    }
    
    // Eventos de clique nos botões de dificuldade
    document.querySelector('.easy').addEventListener('click', () => setDifficulty('easy'));
    document.querySelector('.normal').addEventListener('click', () => setDifficulty('normal'));
    document.querySelector('.hard').addEventListener('click', () => setDifficulty('hard'));
    
    // Evento de pressionar tecla enter
    document.addEventListener('keydown', (e) => {
      if (e.key == 'Enter' && game_state == 'Start') {
        startGame();
      } else if (e.key == 'Enter' && game_state == 'End') {
        showDifficultyMenu();
      } else if (e.key == 'h' || e.key == 'H') {
        showHighScores();
      }
    });
    
    // Iniciar jogo
    function startGame() {
      document.querySelectorAll('.pipe_sprite').forEach((e) => {
        e.remove();
      });
      
      bird.style.top = '40vh';
      game_state = 'Play';
      message.innerHTML = '';
      score_title.innerHTML = 'Pontos: ';
      score_val.innerHTML = '0';
      
      // Resetar velocidade
      move_speed = base_speed;
      gravity = base_gravity;
      
      play();
    }
    
    // Aumentar dificuldade com base na pontuação
    function increaseDifficulty() {
      let score = parseInt(score_val.innerHTML);
      if (score > 0 && score % speed_increase_interval === 0) {
        move_speed += speed_increase_amount;
      }
    }
    
    // Jogo principal
    function play() {
      function move() {
        if (game_state != 'Play') return;
        
        let pipe_sprite = document.querySelectorAll('.pipe_sprite');
        pipe_sprite.forEach((element) => {
          let pipe_sprite_props = element.getBoundingClientRect();
          bird_props = bird.getBoundingClientRect();
          
          // Remover canos que saíram da tela
          if (pipe_sprite_props.right <= 0) {
            element.remove();
          } else {
            // Detectar colisão
            if (
              bird_props.left < pipe_sprite_props.left +
              pipe_sprite_props.width &&
              bird_props.left +
              bird_props.width > pipe_sprite_props.left &&
              bird_props.top < pipe_sprite_props.top +
              pipe_sprite_props.height &&
              bird_props.top +
              bird_props.height > pipe_sprite_props.top
            ) {
              endGame();
              return;
            } else {
              // Aumentar pontuação ao passar por um cano
              if (
                pipe_sprite_props.right < bird_props.left &&
                pipe_sprite_props.right + 
                move_speed >= bird_props.left &&
                element.increase_score == '1'
              ) {
                score_val.innerHTML = +score_val.innerHTML + 1;
                increaseDifficulty();
              }
              element.style.left = 
                pipe_sprite_props.left - move_speed + 'px';
            }
          }
        });
        
        requestAnimationFrame(move);
      }
      requestAnimationFrame(move);
      
      let bird_dy = 0;
      function apply_gravity() {
        if (game_state != 'Play') return;
        
        bird_dy = bird_dy + gravity;
        
        document.addEventListener('keydown', (e) => {
          if (e.key == 'ArrowUp' || e.key == ' ') {
            bird_dy = -7.6;
          }
        });
        
        // Detecta se o pássaro colidiu
        if (bird_props.top <= 0 ||
            bird_props.bottom >= background.bottom) {
          endGame();
          return;
        }
        bird.style.top = bird_props.top + bird_dy + 'px';
        bird_props = bird.getBoundingClientRect();
        requestAnimationFrame(apply_gravity);
      }
      requestAnimationFrame(apply_gravity);
      
      let pipe_seperation = 0;
      let pipe_gap = 35;
      function create_pipe() {
        if (game_state != 'Play') return;
        
        if (pipe_seperation > 115) {
          pipe_seperation = 0
          
          let pipe_posi = Math.floor(Math.random() * 43) + 8;
          
          // Cano de cima
          let pipe_sprite_top = document.createElement('div');
          pipe_sprite_top.className = 'pipe_sprite pipe_top';
          pipe_sprite_top.style.top = pipe_posi - 70 + 'vh';
          pipe_sprite_top.style.left = '100vw';
          pipe_sprite_top.style.height = '70vh';
          document.body.appendChild(pipe_sprite_top);
          
          // Cano de baixo
          let pipe_sprite_bottom = document.createElement('div');
          pipe_sprite_bottom.className = 'pipe_sprite pipe_bottom';
          pipe_sprite_bottom.style.top = pipe_posi + pipe_gap + 'vh';
          pipe_sprite_bottom.style.left = '100vw';
          pipe_sprite_bottom.style.height = '70vh';
          pipe_sprite_bottom.increase_score = '1';
          document.body.appendChild(pipe_sprite_bottom);
        }
        pipe_seperation++;
        requestAnimationFrame(create_pipe);
      }
      requestAnimationFrame(create_pipe);
    }
    
    // Finalizar jogo
    function endGame() {
      game_state = 'End';
      message.innerHTML = 'Fim de Jogo! Pressione Enter';
      message.style.left = '0';
      
      // Salvar pontuação
      let difficulty = '';
      if (base_speed === 2) difficulty = 'Fácil';
      else if (base_speed === 3) difficulty = 'Normal';
      else if (base_speed === 4) difficulty = 'Difícil';
      
      saveScore(parseInt(score_val.innerHTML), difficulty);
      showHighScores();
    }
    
    // Mostrar menu de dificuldade ao carregar a página
    showDifficultyMenu();